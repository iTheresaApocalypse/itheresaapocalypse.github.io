# Kuan Zhang CV — LaTeX 复刻工程

本工程根据个人主页上的一页英文 CV 手工重建，并于 2026-10-25 更新：survey 已标为 TMLR 2026；Scaling in Games 使用主页上的完整标题，并标注 Hugging Face Daily Paper #5。保留原有字体、粗体、下划线、共同贡献标记、照片和一页布局。

## 编辑和编译

- 主文件：`main.tex`。
- 编译器：**XeLaTeX**。
- Overleaf：上传完整的 `Kuan_Zhang_CV_Source.zip`，选择 `main.tex` 为主文件，编译器选择 XeLaTeX。
- 本机：在本目录运行 `./build.sh`，输出为 `build/main.pdf`。脚本会运行两次 XeLaTeX。
- Codex：打开本工程目录即可编辑并预览。

字体、照片、原模板类文件、行距样式和本机 BasicTeX 缺少的六个小型 TeX 包均已随工程提供，无须把字体安装到系统。`support/texmf` 内含 realscripts、xifthen、ifmtarg、titlesec、enumitem、nth；`build.sh` 和 `.latexmkrc` 会配置本地搜索路径。

## 文件

- `main.tex`：可编辑的简历内容及针对原 PDF 的排版参数。
- `resume.cls`、`linespacing_fix.sty`、`fontawesome.sty`：作者公开配套仓库中的模板文件，保留原文。
- `fonts/`：Fontin 小型大写、TeX Gyre Termes 正文家族及模板图标字体。
- `images/you.png`：从原 CV PDF 中无损提取的照片，保留透明通道。
- `support/texmf/`：少量本地编译依赖，包含包自身的许可声明和 TeX Live 包元数据。
- `LICENSE`：配套仓库原有的 Apache 2.0 许可；原始 Overleaf 主文件在其页面标为 CC BY 4.0。

这是根据 PDF 重建的可编辑源文件，不是从作者 Overleaf 账户导出的历史工程。

## 来源及保存的原文档

1. 用户指定的模板：
   https://cn.overleaf.com/latex/templates/chinese-resume-template-zhong-wen-jian-li-mo-ban/fbdypsjmgwbb
   作者 xiangrongjingujiu，页面许可 CC BY 4.0。
2. 模板作者公开的中英双语配套仓库（原 xiangrongjingujiu/resume-template，现重定向为 changren-wcr/resume-template）：
   https://github.com/changren-wcr/resume-template
   下载快照 commit：`ecae2911e4a173171cd6f7eff2821c4492c16dbe`。
3. 参考 CV：
   https://itheresaapocalypse.github.io/files/resume_eng.pdf?v=20261018-supervisors
4. TeX 依赖：TeX Live / CTAN，下载日期 2026-10-25。
   https://ctan.org/pkg/realscripts
   https://ctan.org/pkg/xifthen
   https://ctan.org/pkg/ifmtarg
   https://ctan.org/pkg/titlesec
   https://ctan.org/pkg/enumitem
   https://ctan.org/pkg/nth

工作区的 `original-template/resume-overleaf-original.tex` 是从指定 Overleaf 页面下载并提取的原始主文件。Overleaf 的整包入口要求登录，因此另存了作者公开配套仓库的完整 ZIP 和解压文件，未把这个配套仓库冒充该页面的原始整包。`reference/resume_eng-original.pdf` 保存了下载的原 CV。

## 核对结果（2026-10-25 更新版）

- XeLaTeX 本机编译通过，输出仍为一页 A4；已渲染检查，无裁切、重叠或缺字。
- survey 的发表状态为 TMLR 2026。
- Scaling in Games 标注 Hugging Face Daily Paper #5，并链接到论文的 HF 页面。
- 照片、字体、姓名强调格式和其余内容沿用原版。
- 当前 PDF 为 `output/pdf/Kuan_Zhang_CV.pdf`；网站公开版本为 `files/resume_eng.pdf`。
- 官网 Scaling in Games 已置顶，所有论文的 GitHub 链接采用标准 Octocat 图标，仅该论文显示 stars。网页每天从 GitHub 公开 API 获取并缓存 star 数；每日自动任务于北京时间 09:17 同步 `_data/github_stars.json`。API 暂时不可用时，网页保留最近的快照。可选的 GitHub Actions 工作流保存在工作区 `output/update-github-stars-optional.yml`，尚未部署（本机 token 缺少 workflow scope）。
