#!/bin/sh
# Build locally with XeLaTeX. The small support tree fills gaps in BasicTeX.
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export TEXINPUTS="$PWD/support/texmf/tex//:${TEXINPUTS:-}"
mkdir -p build
for pass in 1 2; do
  xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build main.tex > build/compile.log 2>&1 || {
    cat build/compile.log
    exit 1
  }
done
printf 'Built: %s/build/main.pdf\n' "$PWD"
