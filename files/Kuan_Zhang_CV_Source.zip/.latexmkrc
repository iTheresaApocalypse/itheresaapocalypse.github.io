$pdf_mode = 5;
$ENV{'TEXINPUTS'} = './support/texmf/tex//:' . ($ENV{'TEXINPUTS'} // '');
